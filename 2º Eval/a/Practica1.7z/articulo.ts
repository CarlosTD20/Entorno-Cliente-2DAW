export interface Articulo {
    id:string,
    nombre:string,
    descripcion:string,
    precio:number
}
